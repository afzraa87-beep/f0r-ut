// Play/pause YouTube clip by focusing iframe (simple approach)
// This toggles visibility of iframe player and auto-plays using postMessage API
const playBtn = document.getElementById('playBtn');
const ytIframe = document.getElementById('ytiframe');

playBtn && playBtn.addEventListener('click', () => {
    // Show the iframe container and ask it to play
    const playerDiv = document.getElementById('ytPlayer');
    if(!playerDiv) return;
    // If already visible, hide and stop
    if(playerDiv.style.display === 'block') {
        // stop by reloading iframe with autoplay=0
        ytIframe.src = ytIframe.src.replace('autoplay=1','autoplay=0');
        playerDiv.style.display = 'none';
        playBtn.textContent = '🎵 Play Our Song';
    } else {
        // add autoplay param
        if(ytIframe.src.indexOf('autoplay=1') === -1) {
            ytIframe.src = ytIframe.src + '&autoplay=1';
        }
        playerDiv.style.display = 'block';
        playBtn.textContent = '⏸️ Pause Music';
    }
});

// floating hearts generator
const hearts = document.querySelector('.hearts');
function spawnHeart(){
  const el = document.createElement('div');
  el.className = 'h';
  el.textContent = '💗';
  el.style.left = Math.random() * 100 + 'vw';
  el.style.fontSize = (12 + Math.random()*20) + 'px';
  el.style.animationDuration = (3 + Math.random()*3) + 's';
  hearts.appendChild(el);
  setTimeout(()=> el.remove(), 7000);
}
setInterval(spawnHeart, 650);
